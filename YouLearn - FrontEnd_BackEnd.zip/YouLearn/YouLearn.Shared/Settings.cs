﻿namespace YouLearn.Shared
{
    public static class Settings
    {
        public static string ConnectionString = @"Server=.\sqlexpress;Database=YouLearnCurso;Trusted_Connection=True;";
    }
}
