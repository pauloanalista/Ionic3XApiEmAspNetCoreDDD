﻿namespace YouLearn.Domain.Arguments.Base
{
    public class Response
    {
        public string Message { get; set; }
    }
}
