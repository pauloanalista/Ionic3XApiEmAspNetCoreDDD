﻿namespace YouLearn.Domain.Arguments.Canal
{
    public class AdicionarCanalRequest
    {
        public string Nome { get; set; }
        public string UrlLogo { get; set; }
    }
}
