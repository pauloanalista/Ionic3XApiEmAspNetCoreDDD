﻿namespace YouLearn.Domain.Arguments.PlayList
{
    public class AdicionarPlayListRequest
    {
        public string Nome { get; set; }
    }
}
