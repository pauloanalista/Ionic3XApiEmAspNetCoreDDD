﻿namespace YouLearn.Domain.Enums
{
    public enum EnumStatus
    {
        EmAnalise = 0,
        Aprovado = 1,
        Recusado = 2
    }
}
