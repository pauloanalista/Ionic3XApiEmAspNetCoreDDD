import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { DomSanitizer } from '@angular/platform-browser';

@IonicPage()
@Component({
  selector: 'page-play-video',
  templateUrl: 'play-video.html',
})
export class PlayVideoPage {

  urlSecurity : any;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private domSanitizer : DomSanitizer
  ) {
    let url = this.navParams.get('url');

    this.urlSecurity = this.domSanitizer.bypassSecurityTrustResourceUrl(url);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PlayVideoPage');
  }

}
